package com.dicoding.naufal.footballmatchschedule.mvp.detailteam.adapter

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import com.dicoding.naufal.footballmatchschedule.mvp.detailteam.overview.OverviewFragment
import com.dicoding.naufal.footballmatchschedule.mvp.detailteam.player.PlayerFragment

class DetailTeamPagerAdapter(fragmentManager: FragmentManager, idTeam: String?) : FragmentStatePagerAdapter(fragmentManager) {
    private val list: List<Fragment> = listOf(OverviewFragment.newInstance(idTeam), PlayerFragment.newInstance(idTeam))
    private val title: List<String> = listOf("Overview", "Players")

    override fun getCount(): Int = list.size

    override fun getItem(position: Int): Fragment = list[position]

    override fun getPageTitle(position: Int): CharSequence? = title[position]

}