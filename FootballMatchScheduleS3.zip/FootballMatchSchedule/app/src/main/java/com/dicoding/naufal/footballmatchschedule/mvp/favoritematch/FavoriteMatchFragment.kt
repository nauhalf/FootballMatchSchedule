package com.dicoding.naufal.footballmatchschedule.mvp.favoritematch

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import com.dicoding.naufal.footballmatchschedule.R.color.colorAccent
import com.dicoding.naufal.footballmatchschedule.R.color.colorPrimary
import com.dicoding.naufal.footballmatchschedule.model.event.Event
import com.dicoding.naufal.footballmatchschedule.mvp.detail.DetailActivity
import com.dicoding.naufal.footballmatchschedule.mvp.favoritematch.adapter.FavoriteMatchAdapter
import com.dicoding.naufal.footballmatchschedule.utils.invisible
import com.dicoding.naufal.footballmatchschedule.utils.visible
import org.jetbrains.anko.*
import org.jetbrains.anko.recyclerview.v7.recyclerView
import org.jetbrains.anko.support.v4.onRefresh
import org.jetbrains.anko.support.v4.startActivity
import org.jetbrains.anko.support.v4.swipeRefreshLayout

class FavoriteMatchFragment : Fragment(), FavoriteMatchView {

    private lateinit var swipe : SwipeRefreshLayout
    private lateinit var recyclerView : RecyclerView
    private lateinit var progressBar : ProgressBar
    private var list : MutableList<Event> = mutableListOf()
    private lateinit var matchAdapter : FavoriteMatchAdapter
    private lateinit var presenter : FavoriteMatchPresenter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {

        val view = FavoriteMatchFragmentUI().createView(AnkoContext.create(container!!.context, this))

        setup()

        return view
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        matchAdapter = FavoriteMatchAdapter(list){
            startActivity<DetailActivity>("events" to it)
        }
    }

    override fun showLoading() {
        progressBar.visible()
    }

    override fun hideLoading() {
        progressBar.invisible()
    }

    override fun showList(event: List<Event>) {
        swipe.isRefreshing = false
        list.clear()
        list.addAll(event)

        matchAdapter.notifyDataSetChanged()
    }

    private fun setup(){
        presenter = FavoriteMatchPresenter(this)
        presenter.getFavMatch(true, this.requireContext())
        recyclerView.adapter = matchAdapter
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.setHasFixedSize(true)
        swipe.onRefresh{
            presenter.getFavMatch(false, this.requireContext())
        }
    }

    inner class FavoriteMatchFragmentUI : AnkoComponent<Fragment>{
        override fun createView(ui: AnkoContext<Fragment>): View = with(ui){
            linearLayout {
                lparams(width = matchParent, height = matchParent)
                orientation = LinearLayout.VERTICAL
                isClickable = true

                swipe = swipeRefreshLayout {
                    setColorSchemeResources(colorAccent,
                            android.R.color.holo_green_light,
                            android.R.color.holo_orange_light,
                            colorPrimary)


                    relativeLayout {
                        lparams(width = matchParent, height = matchParent)
                        recyclerView = recyclerView {
                            lparams(width = matchParent, height = matchParent)
                        }
                        progressBar = progressBar {

                        }.lparams{
                            centerInParent()
                        }
                    }
                }
            }
        }
    }
}
