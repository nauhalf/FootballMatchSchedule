package com.dicoding.naufal.footballmatchschedule.mvp.favoritematch

import com.dicoding.naufal.footballmatchschedule.model.event.Event


interface FavoriteMatchView {
    fun showLoading()
    fun hideLoading()
    fun showList(event: List<Event>)
}