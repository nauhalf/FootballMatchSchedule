package com.dicoding.naufal.footballmatchschedule.mvp.main.lastmatch.adapter

import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import com.dicoding.naufal.footballmatchschedule.R
import com.dicoding.naufal.footballmatchschedule.model.event.Event
import com.dicoding.naufal.footballmatchschedule.mvp.item.ItemMatchUI
import com.dicoding.naufal.footballmatchschedule.utils.DateTimeUtilities
import kotlinx.android.extensions.LayoutContainer
import org.jetbrains.anko.AnkoContext
import org.jetbrains.anko.find

class NextMatchAdapter(private val events: List<Event>,
                       private val listener: (Event) -> Unit)
    : RecyclerView.Adapter<NextMatchAdapter.ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return NextMatchAdapter.ViewHolder(ItemMatchUI().createView(AnkoContext.create(parent.context, parent)))
    }

    override fun getItemCount(): Int = events.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindItems(events[position], listener)
    }

    class ViewHolder(override val containerView: View?) : RecyclerView.ViewHolder(containerView), LayoutContainer{
        private val txtScheduleDate = itemView.find<TextView>(R.id.txt_schedule_date)
        private val txtHomeTeam = itemView.find<TextView>(R.id.txt_home_team)
        private val txtAwayTeam = itemView.find<TextView>(R.id.txt_away_team)
        fun bindItems(events: Event, listener: (Event) -> Unit){
            txtScheduleDate.text = DateTimeUtilities.convertDate(events.date, "yyyy-MM-dd", "EEE, dd MMM yyyy")
            txtHomeTeam.text = events.homeTeam
            txtAwayTeam.text = events.awayTeam

            itemView.setOnClickListener {
                listener(events)
            }
        }
    }
}