package com.dicoding.naufal.footballmatchschedule.mvp.detail

import com.dicoding.naufal.footballmatchschedule.model.team.Team

interface DetailView {
    fun showLoading()
    fun hideLoading()
    fun showMatch(home : Team, away : Team)
}