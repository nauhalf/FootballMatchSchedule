package com.dicoding.naufal.footballmatchschedule.mvp.favoritematch

import android.content.Context
import com.dicoding.naufal.footballmatchschedule.helper.database
import com.dicoding.naufal.footballmatchschedule.model.event.Event
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.select
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class FavoriteMatchPresenter(private val view: FavoriteMatchView){

    fun getFavMatch(progressbar: Boolean, context: Context){
        if(progressbar)
            view.showLoading()

        doAsync {
            context?.database?.use {
                val result = select(Event.TABLE_FAVORITE_MATCH).parseList(classParser<Event>())


                uiThread {
                    if(progressbar)
                        view.hideLoading()
                    view.showList(result)
                }
            }
        }
    }
}