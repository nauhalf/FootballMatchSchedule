package com.dicoding.naufal.footballmatchschedule.model.event

data class EventResponses(val events: List<Event>)