package com.dicoding.naufal.footballmatchschedule.mvp.detail

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.widget.Toolbar
import android.view.Menu
import android.view.MenuItem
import com.dicoding.naufal.footballmatchschedule.R
import com.dicoding.naufal.footballmatchschedule.R.drawable.ic_add_to_favorites
import com.dicoding.naufal.footballmatchschedule.R.drawable.ic_added_to_favorites
import com.dicoding.naufal.footballmatchschedule.R.id.add_to_favorite
import com.dicoding.naufal.footballmatchschedule.R.menu.detail_menu
import com.dicoding.naufal.footballmatchschedule.api.ApiRepository
import com.dicoding.naufal.footballmatchschedule.model.event.Event
import com.dicoding.naufal.footballmatchschedule.model.team.Team
import com.dicoding.naufal.footballmatchschedule.utils.DateTimeUtilities
import com.dicoding.naufal.footballmatchschedule.utils.invisible
import com.dicoding.naufal.footballmatchschedule.utils.visible
import com.google.gson.Gson
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity(), DetailView {
    private lateinit var presenter : DetailPresenter
    private lateinit var event : Event
    private lateinit var teamHome : Team
    private lateinit var teamAway : Team
    private var menuItem : Menu? = null
    private var isFavorite : Boolean = false
    private var id : Long? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        setup()
        presenter.getMatchInfo(event.homeId, event.awayId)
        isFavorite = presenter.stateFavorite(this.applicationContext, event.idEvent!!)
    }

    private fun setup(){
        setSupportActionBar(toolbar as Toolbar?)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)


        val intent = intent
        event = intent.getParcelableExtra("events")
        id = event.id
        presenter = DetailPresenter(this, ApiRepository(), Gson())
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when(item!!.itemId){
            android.R.id.home ->{
                finish()
                true
            }
            add_to_favorite -> {
                if(!isFavorite)
                    presenter.addToFavorite(event, this.applicationContext, root)
                else
                    presenter.removeFromFavorite(this.applicationContext, event.idEvent!!, root)

                isFavorite = !isFavorite
                setFavorite()

                true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun showLoading() {
        progress_layout.visible()
    }

    override fun hideLoading() {
        progress_layout.invisible()
    }

    override fun showMatch(home : Team, away : Team) {
        txt_date.text = DateTimeUtilities.convertDate(event.date, "yyyy-MM-dd", "EEE, dd MMM yyyy")
        txt_home_team.text = event.homeTeam
        txt_home_goals.text = event.homeGoalsDetails?.replace(",", "\n")
        txt_home_score.text = event.homeScore
        txt_home_shots.text = event.homeShots
        txt_home_reds.text = event.homeRedCards?.replace(";", newValue = ";\n")
        txt_home_yellows.text = event.homeYellowCards?.replace(";", newValue = ";\n")
        txt_home_goal_keeper.text = event.homeLineupGoalKeeper
        txt_home_defense.text = event.homeLineupDefense?.replace("; ", ";\n")
        txt_home_midfield.text = event.homeLineupMidfield?.replace("; ", ";\n")
        txt_home_forward.text = event.homeLineupForward?.replace("; ", ";\n")
        txt_home_substitutes.text = event.homeLineupSubstitutes?.replace("; ", ";\n")

        txt_away_team.text = event.awayTeam
        txt_away_goals.text = event.awayGoalsDetails?.replace(",", "\n")
        txt_away_score.text = event.awayScore
        txt_away_shots.text = event.awayShots
        txt_away_reds.text = event.awayRedCards?.replace(";", newValue = ";\n")
        txt_away_yellows.text = event.awayYellowCards?.replace(";", newValue = ";\n")
        txt_away_goal_keeper.text = event.awayLineupGoalKeeper
        txt_away_defense.text = event.awayLineupDefense?.replace("; ", ";\n")
        txt_away_midfield.text = event.awayLineupMidfield?.replace("; ", ";\n")
        txt_away_forward.text = event.awayLineupForward?.replace("; ", ";\n")
        txt_away_substitutes.text = event.awayLineupSubstitutes?.replace("; ", ";\n")

        teamHome = home
        teamAway = away
        teamHome.teamBadge?.let { Picasso.get().load(it).into(img_home_team) }
        teamAway.teamBadge?.let { Picasso.get().load(it).into(img_away_team) }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(detail_menu, menu)
        menuItem = menu
        setFavorite()
        return true
    }

    private fun setFavorite(){
        if(isFavorite)
            menuItem?.getItem(0)?.icon = ContextCompat.getDrawable(this, ic_added_to_favorites)
        else
            menuItem?.getItem(0)?.icon = ContextCompat.getDrawable(this, ic_add_to_favorites)
    }

}
