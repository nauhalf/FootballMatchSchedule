package com.dicoding.naufal.footballmatchschedule.mvp.detail

import com.dicoding.naufal.footballmatchschedule.api.ApiRepository
import com.dicoding.naufal.footballmatchschedule.api.sportdbapi.TheSportsDbApi
import com.dicoding.naufal.footballmatchschedule.model.team.TeamResponses
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class DetailPresenter(private val view: DetailView,
                      private val repo: ApiRepository,
                      private val gson: Gson){



    fun getMatchInfo(homeId : String?, awayId : String?){
        view.showLoading()
        doAsync {
            val homeTeam = gson.fromJson(repo.
                    doRequest(
                            TheSportsDbApi
                                    .getTeamById(homeId)
                    ),
                    TeamResponses::class.java
            )

            val awayTeam = gson.fromJson(repo.
                    doRequest(
                            TheSportsDbApi
                                    .getTeamById(awayId)
                    ),
                    TeamResponses::class.java
            )

            uiThread {
                view.showMatch(homeTeam.teams[0], awayTeam.teams[0])
                view.hideLoading()
            }
        }
    }
}