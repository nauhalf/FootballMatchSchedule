package com.dicoding.naufal.footballmatchschedule.mvp.main.nextmatch

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.dicoding.naufal.footballmatchschedule.R
import com.dicoding.naufal.footballmatchschedule.api.ApiRepository
import com.dicoding.naufal.footballmatchschedule.model.event.Event
import com.dicoding.naufal.footballmatchschedule.mvp.detail.DetailActivity
import com.dicoding.naufal.footballmatchschedule.mvp.main.lastmatch.adapter.NextMatchAdapter
import com.dicoding.naufal.footballmatchschedule.utils.invisible
import com.dicoding.naufal.footballmatchschedule.utils.visible
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_next_match.*
import org.jetbrains.anko.support.v4.onRefresh
import org.jetbrains.anko.support.v4.startActivity

class NextMatchFragment : Fragment(), NextMatchView {
    private var list : MutableList<Event> = mutableListOf()
    private lateinit var presenter: NextMatchPresenter
    private lateinit var adapter: NextMatchAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        presenter = NextMatchPresenter(this, ApiRepository(), Gson())
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        presenter.getEventList(true)

        swipe_refresh.onRefresh {
            presenter.getEventList(false)
        }

        recycler_next_match.adapter = adapter
        recycler_next_match.layoutManager = LinearLayoutManager(context)


    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_next_match, container, false)

        adapter = NextMatchAdapter(list){
            startActivity<DetailActivity>("events" to it)
        }

        return view
    }

    override fun showLoading() {
        progress_bar.visible()
    }

    override fun hideLoading() {
        progress_bar.invisible()
    }

    override fun showList(event: List<Event>) {
        swipe_refresh.isRefreshing = false
        list.clear()
        list.addAll(event)
        adapter.notifyDataSetChanged()
    }

}
