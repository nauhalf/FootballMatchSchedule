package com.dicoding.naufal.footballmatchschedule.mvp.main

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.Toolbar
import com.dicoding.naufal.footballmatchschedule.R
import com.dicoding.naufal.footballmatchschedule.mvp.main.adapter.MatchPagerAdapter
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setup()
    }

    fun setup(){
        setSupportActionBar(toolbar as Toolbar?)
        view_pager.adapter = MatchPagerAdapter(supportFragmentManager)
        tab_layout.setupWithViewPager(view_pager)
    }
}
