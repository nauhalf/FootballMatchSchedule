package com.dicoding.naufal.footballmatchschedule.mvp.main.adapter

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import com.dicoding.naufal.footballmatchschedule.mvp.main.lastmatch.LastMatchFragment
import com.dicoding.naufal.footballmatchschedule.mvp.main.nextmatch.NextMatchFragment

class MatchPagerAdapter(fragmentManager: FragmentManager) : FragmentStatePagerAdapter(fragmentManager){

    private val list : List<Fragment> = listOf(LastMatchFragment(), NextMatchFragment())
    private val title : List<String> = listOf("Last Match", "Next Match")

    override fun getCount(): Int = list.size

    override fun getItem(position: Int): Fragment = list[position]

    override fun getPageTitle(position: Int): CharSequence? = title[position]
}