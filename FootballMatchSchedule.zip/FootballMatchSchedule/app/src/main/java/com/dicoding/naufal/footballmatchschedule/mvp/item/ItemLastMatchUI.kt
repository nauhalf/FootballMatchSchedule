package com.dicoding.naufal.footballmatchschedule.mvp.item

import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.dicoding.naufal.footballmatchschedule.R
import com.dicoding.naufal.footballmatchschedule.utils.addRipple
import org.jetbrains.anko.*

class ItemLastMatchUI : AnkoComponent<ViewGroup> {
    override fun createView(ui: AnkoContext<ViewGroup>): View = with(ui){
        linearLayout {
            orientation = LinearLayout.VERTICAL
            lparams(width = matchParent, height = wrapContent){
                topPadding = dip(resources.getDimension(R.dimen.common_padding))
                bottomPadding = dip(resources.getDimension(R.dimen.common_padding))
                leftPadding = dip(resources.getDimension(R.dimen.horizontal_padding))
                rightPadding = dip(resources.getDimension(R.dimen.horizontal_padding))

            }

            isClickable = true
            addRipple()

            textView {
                id = R.id.txt_schedule_date
                gravity = Gravity.CENTER_HORIZONTAL
                textColor = R.color.colorPrimary
                textSize = 16f
            }.lparams(width = matchParent, height = wrapContent)

            linearLayout {
                orientation = LinearLayout.HORIZONTAL
                bottomPadding = dip(7)
                topPadding = dip(7)
                weightSum = 11f

                textView {
                    id = R.id.txt_home_team
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.RIGHT
                    maxLines = 1
                    textSize = 19f
                }.lparams(width = dip(0), height = wrapContent) {
                    weight = 4f
                }

                textView {
                    id = R.id.txt_home_score
                    gravity = Gravity.RIGHT
                    textSize = 20f
                    typeface = Typeface.DEFAULT_BOLD
                }.lparams(width = dip(0), height = wrapContent) {
                    weight = 1f
                }

                textView {
                    gravity = Gravity.CENTER_HORIZONTAL
                    textSize = 18f
                    text = resources.getString(R.string.vs)
                }.lparams(width = dip(0), height = wrapContent) {
                    weight = 1f
                }

                textView {
                    id = R.id.txt_away_score
                    gravity = Gravity.LEFT
                    textSize = 20f
                    typeface = Typeface.DEFAULT_BOLD
                }.lparams(width = dip(0), height = wrapContent) {
                    weight = 1f
                }

                textView {
                    id = R.id.txt_away_team
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.LEFT
                    maxLines = 1
                    textSize = 19f
                }.lparams(width = dip(0), height = wrapContent) {
                    weight = 4f
                }
            }.lparams(width = matchParent, height = wrapContent)
        }
    }
}