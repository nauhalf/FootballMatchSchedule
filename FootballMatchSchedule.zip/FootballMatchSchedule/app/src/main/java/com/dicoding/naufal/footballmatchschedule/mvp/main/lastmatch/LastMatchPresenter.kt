package com.dicoding.naufal.footballmatchschedule.mvp.main.lastmatch

import com.dicoding.naufal.footballmatchschedule.api.ApiRepository
import com.dicoding.naufal.footballmatchschedule.api.sportdbapi.TheSportsDbApi
import com.dicoding.naufal.footballmatchschedule.model.event.EventResponses
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class LastMatchPresenter(private val view: LastMatchView,
                         private val repo: ApiRepository,
                         private val gson: Gson){

    fun getEventList(progressbar: Boolean){
        if(progressbar)
            view.showLoading()

        doAsync {
            val data = gson.fromJson(repo.
                    doRequest(
                            TheSportsDbApi
                                    .getLastMatch("4332")
                    ),
                    EventResponses::class.java
            )

            uiThread {
                if(progressbar)
                    view.hideLoading()
                view.showList(data.events)
            }
        }
    }
}