package com.dicoding.naufal.footballmatchschedule.model.team

data class TeamResponses(val teams: List<Team>)
