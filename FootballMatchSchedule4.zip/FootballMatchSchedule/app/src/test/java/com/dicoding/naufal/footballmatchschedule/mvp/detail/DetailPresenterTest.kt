package com.dicoding.naufal.footballmatchschedule.mvp.detail

import com.dicoding.naufal.footballmatchschedule.api.ApiRepository
import com.dicoding.naufal.footballmatchschedule.api.sportdbapi.TheSportsDbApi
import com.dicoding.naufal.footballmatchschedule.model.event.Event
import com.dicoding.naufal.footballmatchschedule.model.event.EventResponses
import com.dicoding.naufal.footballmatchschedule.model.team.Team
import com.dicoding.naufal.footballmatchschedule.model.team.TeamResponses
import com.dicoding.naufal.footballmatchschedule.utils.TestContextProvider
import com.google.gson.Gson
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Test

import org.junit.Before
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.Mockito.`when`
import org.mockito.MockitoAnnotations

class DetailPresenterTest {

    @Mock
    private lateinit var view: DetailView

    @Mock
    private lateinit var gson: Gson

    @Mock
    private lateinit var apiRepository: ApiRepository

    private lateinit var presenter: DetailPresenter

    @Before
    fun setUp(){
        MockitoAnnotations.initMocks(this)
        presenter = DetailPresenter(view, apiRepository, gson, TestContextProvider())
    }

    @Test
    fun getMatchDetail() {
        val event: MutableList<Event> = mutableListOf()
        val homeTeam: MutableList<Team> = mutableListOf()
        val awayTeam: MutableList<Team> = mutableListOf()
        val eventResponses = EventResponses(event)
        val homeResponse = TeamResponses(homeTeam)
        val awayResponses = TeamResponses(awayTeam)
        val idEvent = "441613"

        GlobalScope.launch {
            `when`(gson.fromJson(apiRepository
                    .doRequest(TheSportsDbApi
                            .getMatchDetail(idEvent)).await(),
                    EventResponses::class.java)).thenReturn(eventResponses)


            `when`(gson.fromJson(apiRepository
                    .doRequest(TheSportsDbApi
                            .getTeamById(event[0].homeId)).await(),
                    TeamResponses::class.java)).thenReturn(homeResponse)


            `when`(gson.fromJson(apiRepository
                    .doRequest(TheSportsDbApi
                            .getTeamById(event[0].awayId)).await(),
                    TeamResponses::class.java)).thenReturn(awayResponses)


            presenter.getMatchDetail(idEvent)
            Mockito.verify(view).showLoading()
            Mockito.verify(view).showMatch(event[0], homeTeam[0], awayTeam[0])
            Mockito.verify(view).hideLoading()
        }
    }
}