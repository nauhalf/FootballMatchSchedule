package com.dicoding.naufal.footballmatchschedule.mvp.main.nextmatch

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.dicoding.naufal.footballmatchschedule.R
import com.dicoding.naufal.footballmatchschedule.api.ApiRepository
import com.dicoding.naufal.footballmatchschedule.model.event.Event
import com.dicoding.naufal.footballmatchschedule.mvp.detail.DetailActivity
import com.dicoding.naufal.footballmatchschedule.mvp.main.nextmatch.adapter.NextMatchAdapter
import com.dicoding.naufal.footballmatchschedule.utils.invisible
import com.dicoding.naufal.footballmatchschedule.utils.visible
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_next_match.*
import org.jetbrains.anko.support.v4.onRefresh
import org.jetbrains.anko.support.v4.startActivity

class NextMatchFragment : Fragment(), NextMatchView {
    private var list : MutableList<Event> = mutableListOf()
    private lateinit var presenter: NextMatchPresenter
    private lateinit var adapter: NextMatchAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_next_match, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = NextMatchAdapter(list){
            startActivity<DetailActivity>("idEvent" to "${it.idEvent}")
        }
        presenter = NextMatchPresenter(this, ApiRepository(), Gson())
        presenter.getEventList(true)

        swipe_refresh?.onRefresh {
            presenter.getEventList(false)
        }

        recycler_view?.adapter = adapter
        recycler_view?.layoutManager = LinearLayoutManager(context)
    }


    override fun showLoading() {
        progress_layout?.visible()
    }

    override fun hideLoading() {
        progress_layout?.invisible()
    }

    override fun showList(event: List<Event>) {
        swipe_refresh?.isRefreshing = false
        list.clear()
        list.addAll(event)
        adapter.notifyDataSetChanged()
    }

}
