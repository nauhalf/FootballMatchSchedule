package com.dicoding.naufal.footballmatchschedule.mvp.main

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.Toolbar
import com.dicoding.naufal.footballmatchschedule.R
import com.dicoding.naufal.footballmatchschedule.R.id.*
import com.dicoding.naufal.footballmatchschedule.mvp.main.favoritematch.FavoriteMatchFragment
import com.dicoding.naufal.footballmatchschedule.mvp.main.lastmatch.LastMatchFragment
import com.dicoding.naufal.footballmatchschedule.mvp.main.nextmatch.NextMatchFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setup(savedInstanceState)
    }

    private fun setup(savedInstanceState: Bundle?){
        setSupportActionBar(toolbar as Toolbar?)


        bottom_nav.setOnNavigationItemSelectedListener { item ->
            when(item.itemId){
                prev_match -> {
                    loadFragment(LastMatchFragment(), LastMatchFragment::class.java.simpleName, savedInstanceState)
                }
                next_match -> {
                    loadFragment(NextMatchFragment(), NextMatchFragment::class.java.simpleName, savedInstanceState)
                }
                fav_match -> {
                    loadFragment(FavoriteMatchFragment(), FavoriteMatchFragment::class.java.simpleName, savedInstanceState)
                }
            }
            true
        }
        bottom_nav.selectedItemId = prev_match
    }

    private fun loadFragment(fragment: Fragment, simpleName: String?, savedInstanceState: Bundle?){
        if(savedInstanceState == null){
            supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.root_container, fragment, simpleName)
                    .commit()
        }
    }
}
