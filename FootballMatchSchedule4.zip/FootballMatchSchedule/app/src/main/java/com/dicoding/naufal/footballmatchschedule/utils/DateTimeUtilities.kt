package com.dicoding.naufal.footballmatchschedule.utils

import java.text.SimpleDateFormat

object DateTimeUtilities {
    fun convertDate(strDate: String?, strOldFormat: String?, strNewFormat: String?) : String {

        val oldFormat = SimpleDateFormat(strOldFormat)
        val newFormat = SimpleDateFormat(strNewFormat)

        return newFormat.format((oldFormat.parse(strDate)))

    }
}