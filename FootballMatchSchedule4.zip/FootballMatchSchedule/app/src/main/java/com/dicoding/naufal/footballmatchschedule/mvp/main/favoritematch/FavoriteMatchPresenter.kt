package com.dicoding.naufal.footballmatchschedule.mvp.main.favoritematch

import android.content.Context
import com.dicoding.naufal.footballmatchschedule.helper.database
import com.dicoding.naufal.footballmatchschedule.model.event.Event
import com.dicoding.naufal.footballmatchschedule.utils.CoroutineContextProvider
import com.dicoding.naufal.footballmatchschedule.utils.EspressoIdlingResource
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.select

class FavoriteMatchPresenter(private val view: FavoriteMatchView,
                             private val context: CoroutineContextProvider = CoroutineContextProvider()) {

    fun getFavMatch(progressbar: Boolean, ctx: Context) {
        if (progressbar)
            view.showLoading()

        EspressoIdlingResource.begin()
        GlobalScope.launch(context.main) {
            ctx?.database?.use {
                val result = select(Event.TABLE_FAVORITE_MATCH).parseList(classParser<Event>())


                if (progressbar)
                    view.hideLoading()
                view.showList(result)
            }
            EspressoIdlingResource.done()
        }
    }
}