package com.dicoding.naufal.footballmatchschedule.helper

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.dicoding.naufal.footballmatchschedule.model.event.Event
import org.jetbrains.anko.db.*

class DatabaseHelper(ctx: Context) : ManagedSQLiteOpenHelper(ctx, "FootballSchedule.db", null, 1) {
    companion object {
        private var instance: DatabaseHelper? = null

        @Synchronized
        fun getInstance(ctx : Context) : DatabaseHelper {
            if(instance == null){
                instance = DatabaseHelper(ctx.applicationContext)
            }
            return instance as DatabaseHelper
        }
    }

    override fun onCreate(db: SQLiteDatabase?) {
        db?.createTable(Event.TABLE_FAVORITE_MATCH, true,
                Event.ID to INTEGER + PRIMARY_KEY + AUTOINCREMENT,
                Event.ID_EVENT to TEXT + UNIQUE,
                Event.DATE to TEXT,
                Event.HOME_ID to TEXT,
                Event.HOME_TEAM to TEXT,
                Event.HOME_SCORE to TEXT,
                Event.HOME_GOALS_DETAILS to TEXT,
                Event.HOME_SHOTS to TEXT,
                Event.HOME_LINEUP_GOAL_KEEPER to TEXT,
                Event.HOME_LINEUP_DEFENSE to TEXT,
                Event.HOME_LINEUP_MIDFIELD to TEXT,
                Event.HOME_LINEUP_FORWARD to TEXT,
                Event.HOME_LINEUP_SUBSTITUTES to TEXT,
                Event.HOME_RED_CARDS to TEXT,
                Event.HOME_YELLOW_CARDS to TEXT,
                Event.AWAY_ID to TEXT,
                Event.AWAY_TEAM to TEXT,
                Event.AWAY_SCORE to TEXT,
                Event.AWAY_GOALS_DETAILS to TEXT,
                Event.AWAY_SHOTS to TEXT,
                Event.AWAY_LINEUP_GOAL_KEEPER to TEXT,
                Event.AWAY_LINEUP_DEFENSE to TEXT,
                Event.AWAY_LINEUP_MIDFIELD to TEXT,
                Event.AWAY_LINEUP_FORWARD to TEXT,
                Event.AWAY_LINEUP_SUBSTITUTES to TEXT,
                Event.AWAY_RED_CARDS to TEXT,
                Event.AWAY_YELLOW_CARDS to TEXT)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.dropTable(Event.TABLE_FAVORITE_MATCH, true)
    }
}

val Context.database : DatabaseHelper
    get() = DatabaseHelper.getInstance(applicationContext)