package com.dicoding.naufal.footballmatchschedule.mvp.detail

import android.content.Context
import android.database.sqlite.SQLiteConstraintException
import android.database.sqlite.SQLiteException
import android.view.View
import com.dicoding.naufal.footballmatchschedule.api.ApiRepository
import com.dicoding.naufal.footballmatchschedule.api.sportdbapi.TheSportsDbApi
import com.dicoding.naufal.footballmatchschedule.helper.database
import com.dicoding.naufal.footballmatchschedule.model.event.Event
import com.dicoding.naufal.footballmatchschedule.model.event.EventResponses
import com.dicoding.naufal.footballmatchschedule.model.team.TeamResponses
import com.dicoding.naufal.footballmatchschedule.utils.CoroutineContextProvider
import com.dicoding.naufal.footballmatchschedule.utils.EspressoIdlingResource
import com.google.gson.Gson
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import org.jetbrains.anko.db.classParser
import org.jetbrains.anko.db.delete
import org.jetbrains.anko.db.insert
import org.jetbrains.anko.db.select
import org.jetbrains.anko.design.snackbar

class DetailPresenter(private val view: DetailView,
                      private val repo: ApiRepository,
                      private val gson: Gson,
                      private val context: CoroutineContextProvider = CoroutineContextProvider()) {


    fun getMatchDetail(idEvent: String?) {
        view.showLoading()

        EspressoIdlingResource.begin()
        GlobalScope.launch(context.main) {
            val event = GlobalScope.async {
                gson.fromJson(repo.doRequest(TheSportsDbApi
                        .getMatchDetail(idEvent)).await(),
                        EventResponses::class.java)
            }

            val homeTeam = GlobalScope.async {
                gson.fromJson(repo.doRequest(
                        TheSportsDbApi
                                .getTeamById(event.await().events[0].homeId)
                ).await(),
                        TeamResponses::class.java
                )
            }

            val awayTeam = GlobalScope.async {
                gson.fromJson(repo.doRequest(
                        TheSportsDbApi
                                .getTeamById(event.await().events[0].awayId)
                ).await(),
                        TeamResponses::class.java
                )
            }
            view.showMatch(event.await().events[0], homeTeam.await().teams[0], awayTeam.await().teams[0])
            view.hideLoading()

            EspressoIdlingResource.done()
        }
    }

    fun addToFavorite(event: Event, context: Context, view: View) {
        try {
            context.database.use {
                insert(Event.TABLE_FAVORITE_MATCH,
                        Event.ID_EVENT to event.idEvent,
                        Event.DATE to event.date,
                        Event.HOME_ID to event.homeId,
                        Event.HOME_TEAM to event.homeTeam,
                        Event.HOME_SCORE to event.homeScore,
                        Event.HOME_GOALS_DETAILS to event.homeGoalsDetails,
                        Event.HOME_SHOTS to event.homeShots,
                        Event.HOME_LINEUP_GOAL_KEEPER to event.homeLineupGoalKeeper,
                        Event.HOME_LINEUP_DEFENSE to event.homeLineupDefense,
                        Event.HOME_LINEUP_MIDFIELD to event.homeLineupMidfield,
                        Event.HOME_LINEUP_FORWARD to event.homeLineupForward,
                        Event.HOME_LINEUP_SUBSTITUTES to event.homeLineupSubstitutes,
                        Event.HOME_RED_CARDS to event.homeRedCards,
                        Event.HOME_YELLOW_CARDS to event.homeYellowCards,
                        Event.AWAY_ID to event.awayId,
                        Event.AWAY_TEAM to event.awayTeam,
                        Event.AWAY_SCORE to event.awayScore,
                        Event.AWAY_GOALS_DETAILS to event.awayGoalsDetails,
                        Event.AWAY_SHOTS to event.awayShots,
                        Event.AWAY_LINEUP_GOAL_KEEPER to event.awayLineupGoalKeeper,
                        Event.AWAY_LINEUP_DEFENSE to event.awayLineupDefense,
                        Event.AWAY_LINEUP_MIDFIELD to event.awayLineupMidfield,
                        Event.AWAY_LINEUP_FORWARD to event.awayLineupForward,
                        Event.AWAY_LINEUP_SUBSTITUTES to event.awayLineupSubstitutes,
                        Event.AWAY_RED_CARDS to event.awayRedCards,
                        Event.AWAY_YELLOW_CARDS to event.awayYellowCards)

            }

            view.snackbar("Added to favorite").show()
        } catch (e: SQLiteException) {
            view.snackbar(e.localizedMessage).show()
        }
    }

    fun removeFromFavorite(context: Context, id: String, view: View) {
        try {
            context.database.use {
                delete(Event.TABLE_FAVORITE_MATCH, "(ID_EVENT = {id})", "id" to id)
            }
            view.snackbar("Remove from favorite").show()
        } catch (e: SQLiteConstraintException) {
            view.snackbar(e.localizedMessage).show()
        } catch (e: SQLiteException) {
            view.snackbar(e.localizedMessage).show()
        }
    }

    fun stateFavorite(context: Context, id: String): Boolean {
        var isFavorite = false
        context.database.use {
            val result = select(Event.TABLE_FAVORITE_MATCH)
                    .whereArgs("(ID_EVENT) = {id}", "id" to id)
            val favorite = result.parseList(classParser<Event>())
            isFavorite = !favorite.isEmpty()
        }
        return isFavorite
    }
}